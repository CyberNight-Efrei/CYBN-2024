class ChunkException(Exception):
    pass

class EncryptionException(Exception):
    pass

class IntegrityException(Exception):
    pass